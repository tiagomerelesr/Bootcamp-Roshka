package com.systemform.stockusuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockusuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockusuariosApplication.class, args);
	}

}

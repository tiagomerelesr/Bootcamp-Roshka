package com.systemform.stockusuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockusuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
